export const homeFaqs = [
  { q: "What does D Expert do?", a: "D Expert builds AI voice agents, AI receptionists, chatbots, CRM, WhatsApp and email automation, high-converting websites and performance marketing systems. We connect them into one growth engine so every call is answered, every lead gets a fast reply and your team spends less time on manual work." },
  { q: "Will AI replace my staff?", a: "No. We design AI systems to support your team: handling missed calls, after-hours enquiries and repetitive questions so your people can focus on customers and higher-value work. Every system includes easy hand-off to a human." },
  { q: "How quickly can I get started?", a: "Most clients have their first automation or AI agent live within 1–2 weeks. Full websites take 3–6 weeks, and marketing campaigns can launch within a week of tracking being set up." },
  { q: "Do you work with businesses outside India?", a: "Yes. We're based in New Delhi and work with clients across India, the United States, the UK, the UAE, Canada and Australia, with calls scheduled in your time zone." },
  { q: "Which tools and platforms do you use?", a: "We use best-in-class platforms such as Vapi, Retell AI, ElevenLabs, OpenAI, Claude, n8n, Make, Zapier, GoHighLevel, HubSpot, the WhatsApp Cloud API, Next.js, Google Ads and Meta Ads, and we always build in accounts you own." },
  { q: "How much does it cost?", a: "Monthly plans start from ₹19,999 (about $349), with one-time projects quoted individually. See our pricing page for plan details, or book a free call for a custom quote." },
];

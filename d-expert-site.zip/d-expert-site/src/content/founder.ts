/**
 * Founder content. TODO(owner): Pankaj to review story, timeline years and results for accuracy.
 */
export const founderStory = [
  "I started my career fascinated by one question: why do great businesses lose customers they should have won? Again and again, the answer wasn't the product or the service. It was the gaps: the call nobody answered, the enquiry nobody followed up, the website that didn't explain why they were the best choice.",
  "Working across digital marketing, I saw businesses spend heavily on ads only to lose the leads in the follow-up. When AI and automation matured, I realised the gaps could finally be closed for good, not by hiring more people, but by giving the people a business already has systems that never sleep.",
  "That's why I founded D Expert. We combine AI agents, automation and digital marketing into one growth system, so the phone gets answered, every lead gets a reply in seconds, and owners get their evenings back.",
];

export const founderMission =
  "To give every growing business, from a neighbourhood dental clinic to a fast-scaling startup, the same AI and automation advantages that used to be available only to large enterprises.";

export const founderExperience = [
  { title: "AI Voice Agents & Receptionists", desc: "Designing natural, safe call flows for clinics, restaurants, real estate and service businesses." },
  { title: "Automation & CRM Systems", desc: "Building workflows in n8n, Make, Zapier, GoHighLevel and HubSpot that remove manual work." },
  { title: "Performance Marketing", desc: "Running Google and Meta campaigns with full-funnel tracking and automated follow-up." },
  { title: "Websites & Funnels", desc: "Designing fast, conversion-focused websites and landing pages that plug into sales systems." },
];

export const founderSkills = [
  { label: "AI Automation", value: 95 },
  { label: "AI Voice Agents", value: 95 },
  { label: "AI Chatbots", value: 92 },
  { label: "Lead Generation", value: 92 },
  { label: "Digital Marketing", value: 90 },
  { label: "Web Design", value: 90 },
  { label: "CRM Automation", value: 90 },
  { label: "Google Ads", value: 88 },
  { label: "Meta Ads", value: 88 },
];

export const founderPhilosophy = [
  { title: "Systems over hustle", desc: "Sustainable growth comes from systems that work every day, not heroic effort.", icon: "Workflow" },
  { title: "AI supports people", desc: "AI should handle repetitive work so people can do the human work better, never replace the care customers value.", icon: "Handshake" },
  { title: "Measure everything", desc: "If it isn't tracked, it can't be improved. Every system ships with clear reporting.", icon: "ChartLine" },
  { title: "Honest advice", desc: "If something won't move the needle for you, I'll say so, even if it means a smaller project.", icon: "ShieldCheck" },
];

export const founderTimeline = [
  { year: "Early career", title: "Digital marketing foundations", desc: "Started in digital marketing, running campaigns and building websites for local businesses." },
  { year: "Growth", title: "From campaigns to systems", desc: "Saw that leads were lost in follow-up, and began building CRM and email automation for clients." },
  { year: "AI shift", title: "Embracing AI agents", desc: "Started building AI chatbots and workflow automations as large language models matured." },
  { year: "D Expert", title: "Founded D Expert", desc: "Brought AI voice agents, automation and marketing together into one growth system." },
  { year: "Today", title: "50+ projects delivered", desc: "Helping clinics, local businesses, agencies and startups in India and abroad scale with AI." },
];

export const founderWhy = [
  "You work directly with Pankaj, not a junior account manager.",
  "One partner for AI, automation, websites and marketing, so nothing falls through the gaps.",
  "Plain-English advice with clear priorities and honest timelines.",
  "Systems built in your accounts. You own everything.",
  "Ongoing optimisation, not set-and-forget.",
  "AI that supports your team and respects your customers.",
];

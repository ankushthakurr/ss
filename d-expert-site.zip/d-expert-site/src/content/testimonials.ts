/**
 * PLACEHOLDER testimonials written to show the layout.
 * TODO(owner): replace with real, verified client testimonials (with permission) before launch.
 */
export const testimonials = [
  {
    quote: "We were missing calls every time we were with a patient. The AI receptionist now picks up instantly, books appointments into our calendar and sends reminders. My front desk team finally has breathing room.",
    name: "Dr. Ananya Mehra",
    role: "Dental Clinic Owner",
    location: "New Delhi",
    rating: 5,
    service: "AI Receptionist",
  },
  {
    quote: "Friday and Saturday nights used to mean a phone nobody could answer. Now reservations come in through the AI assistant and WhatsApp while my staff look after guests.",
    name: "Arjun Sethi",
    role: "Restaurant Owner",
    location: "Gurugram",
    rating: 5,
    service: "AI Booking Assistant",
  },
  {
    quote: "Pankaj rebuilt our website and set up instant replies for every quote request. Leads get a text before I've even put down my tools, and the jobs coming in are better qualified.",
    name: "Mark Daniels",
    role: "Roofing Contractor",
    location: "Texas, USA",
    rating: 5,
    service: "Website + Lead Automation",
  },
  {
    quote: "Our portal leads used to go cold in hours. Now every lead gets a call within a minute and the CRM fills itself. My agents only spend time with serious buyers.",
    name: "Rohit Malhotra",
    role: "Real Estate Agency Director",
    location: "Noida",
    rating: 5,
    service: "AI Lead Qualification",
  },
  {
    quote: "Order-status questions were eating our whole day. The AI support agent handles them on WhatsApp in seconds and the email flows recover carts automatically.",
    name: "Neha Kapoor",
    role: "Ecommerce Store Owner",
    location: "Mumbai",
    rating: 5,
    service: "Ecommerce Automation",
  },
  {
    quote: "D Expert gave us a brand, website, funnel and CRM in one go. We launched looking like a company five times our size, and the automations run our follow-ups.",
    name: "Kabir Anand",
    role: "Startup Founder",
    location: "Bengaluru",
    rating: 5,
    service: "Startup Growth System",
  },
];

/** PLACEHOLDER stats from the brief. TODO(owner): confirm these numbers are accurate. */
export const trustStats = [
  { value: 50, suffix: "+", label: "Projects Completed" },
  { value: 100, suffix: "+", label: "Automations Built" },
  { value: 30, suffix: "+", label: "Websites Created" },
  { value: 95, suffix: "%", label: "Client Satisfaction" },
];

/**
 * PLACEHOLDER client wordmarks rendered as styled text.
 * TODO(owner): replace with real client logos (SVG in /public/logos) and permission to display them.
 */
export const clientLogos = [
  { name: "BrightSmile Dental", style: "font-semibold tracking-tight" },
  { name: "Spice Route", style: "italic font-serif" },
  { name: "SkyHigh Roofing", style: "font-black uppercase tracking-widest text-sm" },
  { name: "Urban Nest Realty", style: "font-light tracking-[0.2em] uppercase text-sm" },
  { name: "Lexis Legal", style: "font-serif font-semibold" },
  { name: "IronCore Gym", style: "font-extrabold uppercase italic" },
  { name: "Wanderlux", style: "font-medium tracking-wide" },
  { name: "BuildRight", style: "font-bold" },
  { name: "Cura Health", style: "font-semibold tracking-tight" },
  { name: "Loom & Co.", style: "font-serif italic" },
];
